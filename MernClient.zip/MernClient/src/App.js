import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Login from './Components/Assets/Login/login';
import UserDashboard from './Components/Assets/User-Dashboard/user-dash';
import AdminDashboard from './Components/Assets/Admin-Dashboard/admin-dash';
import AllBooks from './Components/Assets/Books/AllBooks';
import ABooks from './Components/Assets/Books-Admin/ABooks';
import BookDetails from './Components/Assets/bookDetails/bookdet'; 
import AddBooks from './Components/Assets/AddBooks/AddBooks'; // Import AddBooks component
import './App.css';
import ManageBooks from './Components/Assets/ManageBooks/ManageBooks';


function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (username, password) => {
    if (username === 'user' && password === 'userpass') {
      // User login successful
      return true;
    } else if (username === 'admin' && password === 'adminpass') {
      // Admin login successful
      return true;
    } else {
      // Handle invalid login
      return false;
    }
  };

  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={<Login onLogin={handleLogin} />} // Pass onLogin function as a prop
        />
        <Route path="/user-dashboard" element={<UserDashboard />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/all-books" element={<AllBooks />} />
        <Route path="/abooks" element={<ABooks />} />
        <Route path="/book-details/:id" element={<BookDetails />} />
        <Route path="/add-books" element={<AddBooks />} /> 
        <Route path="/admin-dashboard/manage-books/:id" element={<ManageBooks />} /> 
   
      </Routes>
    </Router>
  );
}

export default App;
