import React from 'react';
import { Link } from 'react-router-dom'; 
import './user-dash.css';

function UserDashboard() {
  return (
    <div className="dashboard-container">
      <div id="menu">
        <ul>
          <li><Link to="/">Home</Link></li> {/* Link to home */}
          <li><Link to="/all-books">All-Books</Link></li> {/* Link to All-Books */}
          <li><Link to="/">Logout</Link></li> {/* Link to logout */}
        </ul>
      </div>
      <div className="content">
        <div id="search-box">
          <input type="text" placeholder="Search Books" />
          <button onClick={searchBooks}>Search</button>
        </div>
        <div id="welcome-message">
          <h2>Welcome to Your Dashboard</h2>
          <p>Access your favorite books at an affordable cost!</p>
        </div>
      </div>
    </div>
  );
}

function searchBooks() {
  var searchTerm = document.querySelector("#search-box input[type='text']").value;
  console.log("Searching for: " + searchTerm);
}

export default UserDashboard;
