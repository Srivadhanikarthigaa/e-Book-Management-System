import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './bookdet.css';

function BookDetails() {
  // Extracting book details from location state
  const { state } = useLocation();
  const book = state && state.book;
  const [showFullDescription, setShowFullDescription] = useState(false);

  // Toggle function for showing full description
  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  return (
    <div className="book-details-container">
      <div id="menu">
        <ul>
          <li><Link to="/user-dashboard">Home</Link></li>
          <li><Link to="/all-books">All-Books</Link></li>
          <li><Link to="/">Logout</Link></li>
        </ul>
      </div>
      <div className="content">
        <h1>BOOK INFORMATION</h1>
        {book ? (
          <div className="book-details">
            <img src={book.imageURL} alt={book.title} className="book-image" />
            <h2>{book.title}</h2>
            <p>Author: {book.author}</p>
            <div className="description">
              {showFullDescription ? (
                <p>{book.description}</p>
              ) : (
                <p>{book.description.slice(0, 150)}... <span className="read-more" onClick={toggleDescription}>Read More</span></p>
              )}
            </div>
            <p>Price: {book.price}</p>
          </div>
        ) : (
          <p>No book selected.</p>
        )}
        <div className="back-link">
          <Link to="/all-books">Back to All Books</Link>
        </div>
      </div>
    </div>
  );
}

export default BookDetails;
