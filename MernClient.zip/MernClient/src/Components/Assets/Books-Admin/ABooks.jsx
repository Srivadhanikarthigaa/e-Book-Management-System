import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

import './ABooks.css';

function ABooks() {
  const [booksData, setBooksData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:1024/all-books')
      .then(response => {
        setBooksData(response.data);
      })
      .catch(error => {
        console.error('Error fetching books data:', error);
      });
  }, []);

  const searchBooks = () => {
    var searchTerm = document.querySelector("#search-box input[type='text']").value;
    console.log("Searching for: " + searchTerm);
    // Implement search functionality here
  }

  return (
    <div className="dashboard-container">
      <div id="menu">
        <ul>
          <li><Link to="/admin-dashboard">Home</Link></li>
          <li><Link to="/ABooks">All-Books</Link></li>
          <li><Link to="/">Logout</Link></li>
        </ul>
      </div>
      <div className="content">
        <div id="search-box">
          <input type="text" placeholder="Search Books" />
          <button onClick={searchBooks}>Search</button>
        </div>
        <div id="welcome-message">
          <h2>Welcome to Your Dashboard</h2>
          <p>Access your favorite books at an affordable cost!</p>
        </div>
      </div>

      <div className="all-books">
        <h1 style={{ textAlign: 'center' }}>All Books</h1>
        <div className="books-list">
          {booksData.map((book, index) => (
            <Link key={index} to={{ pathname: `/ABookdet/${index}`, state: { book } }} className="book-link">
              <div className="book">
                <img src={book.imageURL} alt={book.title} />
                <div className="book-details">
                  <h2>{book.title}</h2>
                  <p className="author">Author: <span>{book.author}</span></p>
                  <p className="price">Price: {book.price}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ABooks;
