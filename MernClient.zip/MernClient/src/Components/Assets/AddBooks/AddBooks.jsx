import React, { useState } from 'react';
import { Button } from 'flowbite-react';
import './add-books.css';

const AddBooks = () => {
  const [bookData, setBookData] = useState({
    author: '',
    title: '',
    imageURL: '',
    description: '',
    pdfURL: '',
    price: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBookData({ ...bookData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic input validation
    if (!isValidString(bookData.author) || !isValidString(bookData.title) || !isValidString(bookData.description) || !isValidURL(bookData.imageURL) || !isValidURL(bookData.pdfURL) || !isValidPrice(bookData.price)) {
      alert('Please fill in all fields with valid data.');
      return;
    }

    try {
      const response = await fetch('http://localhost:1024/upload-book', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookData),
      });
      const data = await response.json();
      console.log(data);
      alert('Book uploaded successfully!');
      // Reset form fields
      setBookData({
        author: '',
        title: '',
        imageURL: '',
        description: '',
        pdfURL: '',
        price: ''
      });
    } catch (error) {
      console.error('Error uploading book:', error);
      alert('An error occurred while uploading the book.');
    }
  };

  const isValidString = (str) => {
    // Check if string is not empty
    return str.trim() !== '';
  };

  const isValidURL = (url) => {
    // Simple URL validation regex
    const urlPattern = /^(ftp|http|https):\/\/[^ "]+$/;
    return urlPattern.test(url);
  };

  const isValidPrice = (price) => {
    // Check if price is a valid number
    return !isNaN(parseFloat(price)) && isFinite(price);
  };

  return (
    <div className="add-books-container">
      {/* Title, Author, Description column */}
      <div>
        <div className="input-group">
          <label htmlFor="author">Author:</label>
          <input
            id="author"
            placeholder="Author"
            required
            type="text"
            name="author"
            value={bookData.author}
            onChange={handleChange}
          />
        </div>
        <div className="input-group">
          <label htmlFor="title">Title:</label>
          <input
            id="title"
            placeholder="Title"
            required
            type="text"
            name="title"
            value={bookData.title}
            onChange={handleChange}
          />
        </div>
        <div className="input-group">
          <label htmlFor="description">Description:</label>
          <textarea
            id="description"
            placeholder="Description"
            required
            type="text"
            name="description"
            value={bookData.description}
            onChange={handleChange}
            rows={4}
            className="textarea-group"
          />
        </div>
      </div>

      {/* Image URL, PDF URL, Price column */}
      <div>
        <div className="input-group">
          <label htmlFor="imageURL">Image URL:</label>
          <input
            id="imageURL"
            placeholder="Image URL"
            required
            type="text"
            name="imageURL"
            value={bookData.imageURL}
            onChange={handleChange}
          />
        </div>
        <div className="input-group">
          <label htmlFor="pdfURL">PDF URL:</label>
          <input
            id="pdfURL"
            placeholder="PDF URL"
            required
            type="text"
            name="pdfURL"
            value={bookData.pdfURL}
            onChange={handleChange}
          />
        </div>
        <div className="input-group">
          <label htmlFor="price">Price:</label>
          <input
            id="price"
            placeholder="Price"
            required
            type="text"
            name="price"
            value={bookData.price}
            onChange={handleChange}
          />
        </div>
      </div>

      {/* Submit button */}
      <Button type="submit" className="mt-5" onClick={handleSubmit}>
        Upload book
      </Button>
    </div>
  );
};

export default AddBooks;
