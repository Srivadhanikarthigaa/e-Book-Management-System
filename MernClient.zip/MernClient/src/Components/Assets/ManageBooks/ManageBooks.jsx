import React, { useEffect, useState } from 'react';
import { Table } from 'flowbite-react';
import './manage-books.css'; // Import the CSS file

const ManageBooks = () => {
    const [allBooks, setAllBooks] = useState([]);

    useEffect(() => {
        fetch(`http://localhost:1024/all-books`)
            .then((res) => res.json())
            .then((data) => {
                setAllBooks(data);
                console.log(data); // Log the fetched data to check its structure
            })
            .catch((error) => {
                console.error('Error fetching books:', error);
            });
    }, []);
    

    const handleDelete = (id) => {
        fetch(`http://localhost:1024/book/${id}`, {
            method: "DELETE",
        })
            .then((res) => {
                if (res.ok) {
                    // Remove the deleted book from the state
                    setAllBooks(allBooks.filter(book => book._id !== id));
                } else {
                    throw new Error('Failed to delete book');
                }
            })
            .catch((error) => {
                console.error('Error deleting book:', error);
                // Handle error
            });
    };

    return (
        <div className="table-container">
            <h2>Manage Books</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Book Name</th>
                        <th>Author</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {allBooks.map((book) => (
                        <tr key={book._id}>
                            <td>{book.title}</td>
                            <td>{book.author}</td>
                            <td>
                                <button onClick={() => handleDelete(book._id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default ManageBooks;
