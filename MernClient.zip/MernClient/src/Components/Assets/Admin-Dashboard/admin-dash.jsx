import React from 'react';
import './admin-dash.css'; // Import the CSS file
import { Link } from 'react-router-dom';

function AdminDashboard() {
  // Function to handle adding a book
  const handleAddBook = () => {
    console.log('Adding a book');
    // Add your logic here to handle adding a book
  };

  // Function to handle removing a book
  const handleRemoveBook = () => {
    console.log('Removing a book');
    // Add your logic here to handle removing a book
  };

  // Function to handle updating a book
 // const handleUpdateBook = () => {
   // console.log('Updating a book');
    // Add your logic here to handle updating a book};



  return (
    <div className="dashboard-container">
      <div id="menu">
        <ul>
          <li><Link to="/admin-dashboard">Home</Link></li> {/* Link to home */}
          <li><Link to="/ABooks">All-Books</Link></li> 
          <li><Link to="/">Logout</Link></li> 
        </ul>
      </div>
      <div className="sidebar">
        <h2>Manage Books</h2>
        <ul>
          <li><Link to="/add-books">Add Books</Link></li> {/* Link to Add Books page */}
          <li><Link to="/admin-dashboard/manage-books/:id">Delete Books</Link></li>
        
        </ul>
      </div>

      {/* Main content */}
      <div id="welcome-message">
          <h2>Welcome to Your Dashboard - Admin</h2>
          <p>Access your favorite books at an affordable cost!</p>
      </div>
    </div>
  );
}

export default AdminDashboard;
