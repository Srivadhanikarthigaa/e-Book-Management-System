import React, { useState } from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate(); // Replace useHistory with useNavigate

  const handleSubmit = (event) => {
    event.preventDefault();
    setError('');

    // Check user credentials
    if (username === 'user' && password === 'userpass') {
      // User login successful
      onLogin(username, 'user');
      navigate('/user-dashboard'); // Use navigate to redirect
    }
    // Check admin credentials
    else if (username === 'admin' && password === 'adminpass') {
      // Admin login successful
      onLogin(username, 'admin');
      navigate('/admin-dashboard');
      // Redirect to admin dashboard or other appropriate route
    } else {
      setError('Invalid username or password. Please try again.');
    }
  };

  return (
    <div className='container'>
      <div className='header'>
        <div className='text'>e-Book Management System</div>
      </div>
      <form onSubmit={handleSubmit}>
        <div className='inputs'>
          <div className='input'>
            <div className='text'>Username</div>
            <input
              type='text'
              name='username'
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className='input'>
            <div className='text'>Password</div>
            <input
              type='password'
              name='password'
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        </div>
        {error && <div className='error'>{error}</div>}
        <button type='submit'>Login</button>
      </form>
     
    </div>
  );
}

export default Login;
