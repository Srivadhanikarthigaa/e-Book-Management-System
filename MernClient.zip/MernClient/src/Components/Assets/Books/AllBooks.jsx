import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

import './AllBooks.css';

function AllBooks() {
  const [booksData, setBooksData] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:1024/all-books')
      .then(response => {
        setBooksData(response.data);
      })
      .catch(error => {
        console.error('Error fetching books data:', error);
      });
  }, []);

  const searchBooks = () => {
    var searchTerm = document.querySelector("#search-box input[type='text']").value;
    console.log("Searching for: " + searchTerm);
    // Implement search functionality here
  }

  return (
    <div className="dashboard-container">
      <div id="menu">
        <ul>
          <li><Link to="/user-dashboard">Home</Link></li>
          <li><Link to="/all-books">All-Books</Link></li>
          <li><Link to="/">Logout</Link></li>
        </ul>
      </div>
      <div className="content">
        <div id="search-box">
          <input type="text" placeholder="Search Books" />
          <button onClick={searchBooks}>Search</button>
        </div>
        <div id="welcome-message">
          <h2>Welcome to Your Dashboard</h2>
          <p>Access your favorite books at an affordable cost!</p>
        </div>
      </div>

      <div className="all-books">
        <h1 style={{textAlign:'justify'}}>All Books</h1>
        <div className="books-list">
          {booksData.map((book, index) => (
            <div key={index} className="book">
              <Link to={`/book-details/${index}`} state={{ book }}>
                <img src={book.imageURL} alt={book.title} />
                <div className="book-details">
                  <h2>{book.title}</h2>
                  <p className="author">Author: <span>{book.author}</span></p>
                  <p className="price">Price: {book.price}</p>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AllBooks;
